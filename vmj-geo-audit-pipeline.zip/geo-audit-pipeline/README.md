# 브이앤엠제이피부과 AI 노출(GEO) 자동 측정 대시보드

매일 아침 8시(한국시간)에 자동으로 ChatGPT · Gemini · Claude에게 10개 질문을 던지고,
"실제로 병원이 추천/언급됐는지"를 엄격한 규칙으로 채점해서 웹 대시보드에 쌓아줍니다.
서버를 따로 구입/운영할 필요 없이 **GitHub의 무료 기능만으로** 동작합니다.

- 매일 자동 실행: GitHub Actions (무료, 예약 실행)
- 대시보드 호스팅: GitHub Pages (무료, 정적 웹페이지)
- 결과 저장: 저장소 안의 `docs/data/results.json` 파일 (별도 데이터베이스 불필요)

아래 순서대로만 따라 하시면 됩니다. 명령어 창(터미널)을 쓸 필요 없이 전부 웹 브라우저로 가능합니다.

---

## 1단계. GitHub 계정 만들기

이미 계정이 있다면 건너뛰세요.

1. https://github.com 접속 → **Sign up** → 이메일/비밀번호로 무료 가입.

## 2단계. 새 저장소(repository) 만들기

1. 로그인 후 오른쪽 위 **+** 버튼 → **New repository**
2. Repository name에 원하는 이름 입력 (예: `vmj-geo-audit`)
3. **Public**으로 선택하세요.
   > ⚠️ 무료 GitHub 계정은 **Public 저장소에서만** 대시보드(GitHub Pages)를 무료로 공개할 수 있습니다. Public으로 하면 결과 데이터(노출 여부, 경쟁 병원명 등)가 링크를 아는 누구나 볼 수 있는 상태가 됩니다. 이 데이터를 외부에 공개하고 싶지 않다면 **Private**로 만들고 유료 플랜(GitHub Pro, 월 약 $4)으로 업그레이드해야 GitHub Pages를 쓸 수 있습니다.
4. **Create repository** 클릭.

## 3단계. 이 폴더의 파일 올리기

방금 만든 저장소 페이지에서:

1. **Add file → Upload files** 클릭
2. 이 zip 파일의 압축을 푼 뒤, 그 안의 모든 파일과 폴더(`.github`, `docs`, `scripts`, `package.json`, `README.md`)를 통째로 끌어다 놓기
   > `.github` 폴더처럼 점(.)으로 시작하는 폴더도 반드시 함께 올려야 자동 실행이 동작합니다. 브라우저 업로드 창에 폴더째로 드래그하면 하위 파일까지 그대로 올라갑니다.
3. 아래 **Commit changes** 클릭

## 4단계. API 키 3개 발급받기

세 회사 사이트에서 각각 가입하고 API 키(비밀 문자열)를 발급받으세요. (이 부분은 결제/계정 등록이 필요해 원장님이 직접 진행하셔야 합니다.)

| 플랫폼 | 발급 위치 |
|---|---|
| OpenAI | https://platform.openai.com/api-keys |
| Google Gemini | https://aistudio.google.com/app/apikey |
| Anthropic (Claude) | https://console.anthropic.com/settings/keys |

각 사이트에서 결제 수단을 등록해야 API를 쓸 수 있는 경우가 많습니다. 사용량은 하루 40회 호출 수준이라 비용은 한 달 몇 달러 이내입니다.

## 5단계. 저장소에 API 키 등록하기 (Secrets)

발급받은 키를 코드에 직접 적지 않고, GitHub이 안전하게 보관해주는 "Secrets" 기능에 등록합니다.

1. 저장소 페이지에서 **Settings** 탭 클릭
2. 왼쪽 메뉴에서 **Secrets and variables → Actions**
3. **New repository secret** 클릭, 아래 3개를 하나씩 등록:
   - Name: `OPENAI_API_KEY` / Secret: (OpenAI에서 받은 키)
   - Name: `GEMINI_API_KEY` / Secret: (Gemini에서 받은 키)
   - Name: `ANTHROPIC_API_KEY` / Secret: (Anthropic에서 받은 키)

## 6단계. GitHub Pages 켜기

1. **Settings → Pages**
2. **Build and deployment → Source**를 **Deploy from a branch**로 설정
3. Branch: `main`, 폴더: `/docs` 선택 → **Save**
4. 몇 분 후 이 화면에 대시보드 주소(`https://아이디.github.io/저장소이름/`)가 표시됩니다. 이 링크를 즐겨찾기 해두세요.

## 7단계. 첫 실행해보기

매일 자동으로 돌지만, 지금 바로 첫 데이터를 채우고 싶다면:

1. 저장소의 **Actions** 탭 클릭
2. 왼쪽에서 **Daily GEO check** 선택
3. 오른쪽 **Run workflow** 버튼 → **Run workflow** 다시 클릭
4. 1~2분 정도 기다리면 초록 체크 표시로 완료됩니다. 실패하면 빨간 X가 뜨는데, 클릭해서 로그를 열어보면 어떤 API 키가 잘못됐는지 등 오류 메시지가 보입니다.
5. 완료 후 6단계에서 확인한 대시보드 주소로 접속하면 결과가 채워져 있습니다.

이후로는 매일 한국시간 오전 8시에 자동으로 다시 실행되고, 대시보드도 자동으로 그날 데이터로 갱신됩니다.

---

## 실행 시각 바꾸기

`.github/workflows/daily.yml` 파일 안의 아래 줄을 수정하면 됩니다 (시간은 UTC 기준, 한국시간 = UTC+9):

```yaml
- cron: "0 23 * * *"   # UTC 23:00 = 한국시간 08:00
```

예) 한국시간 오전 7시로 바꾸려면 `"0 22 * * *"`로 수정.

## 질문 문항 바꾸기

`scripts/collect.mjs` 파일 상단의 `QUESTIONS` 배열을 수정하면 됩니다.

## 모델명이 바뀌어서 오류가 날 때

OpenAI · Google · Anthropic은 몇 달에 한 번씩 기본 모델을 교체합니다. `Daily GEO check`가 실패하기 시작하면:

1. `scripts/collect.mjs` 상단의 `OPENAI_MODEL`, `GEMINI_MODEL`, `CLAUDE_MODEL` 값을 각 회사 문서에서 확인한 최신 모델명으로 교체
2. Actions 탭에서 **Run workflow**로 다시 테스트

## 알아두실 점

- 이 파이프라인은 각 회사의 **공식 API**(웹검색 기능 포함)를 사용합니다. chatgpt.com·gemini.google.com 같은 소비자용 웹/앱 화면과는 결과가 다소 다를 수 있습니다(지도·업체 평점 카드, 로그인 개인화 등은 API에 없음). 다만 로그인 개인화로 인한 왜곡(예: 최초 수동 측정 때 발견된 Gemini 계정 편향 문제)은 API 방식에서는 발생하지 않습니다.
- 노출 판정은 Claude API를 "심판"으로 세워 자동 채점합니다. 병원이 지정한 원래 규칙(본문 추천만 인정, 순위 불명확 시 확인 불가, 추측 금지)을 그대로 프롬프트에 반영해뒀습니다.
- 특정 플랫폼 호출이 실패하면 "미노출"이 아니라 "확인 오류"로 별도 표시되어, 오류를 미노출로 오인하지 않도록 했습니다.

## 화면 구성

- **`docs/index.html`** — 메인 화면. 노출 점유율(Share of Voice) 큰 숫자와 전일 대비 증감, 날짜별 추이 그래프(전체/엔진별/순위 보기 전환), 브랜드 랭킹, 모델별·시술별(울쎄라/써마지) 상위 경쟁 병원 표, 질문 목록을 보여줍니다.
- **`docs/prompt.html?q=번호`** — 질문 하나를 클릭하면 열리는 상세 페이지. 그 질문에서만의 노출 추이, 브랜드 랭킹, 인용 출처, 실행 기록(날짜별로 어떤 AI가 언급했는지)을 보여줍니다. 메인 화면의 질문 목록에서 자동으로 링크됩니다.
- **`docs/lib.js`** — 두 화면이 함께 쓰는 집계 로직(브랜드 랭킹 계산, 날짜별 추이, 차트 그리기)입니다. 직접 건드릴 필요는 없습니다.

## 데이터 구조 (참고용)

`docs/data/results.json`은 `{ latest, history }` 형태이며, `history`는 날짜별 스냅샷 배열입니다. 각 스냅샷의 `platforms.{gpt|gemini|claude}.rows[i]`는 질문 i번에 대한 판정 결과로, 다음을 담습니다:

- `exposed` / `rank` — 우리 병원 노출 여부와 순위(불명확하면 `null`)
- `brands` — 그 답변에 실제로 등장한 병원들을 언급 순서대로 나열한 배열 (`{ name, isUs }`). 브랜드 랭킹·모델별/시술별 순위 표는 전부 이 배열을 집계해서 계산합니다.
- `citations` — 답변이 웹검색으로 참고한 도메인 목록. 질문 상세 페이지의 "인용 출처" 표에 쓰입니다.
- `reasoning` — 판정 근거 한 줄.

이 zip에 들어있는 `docs/data/results.json`에는 2026-09-01에 처음 수동으로 측정했던 결과 1건만 기준선(baseline)으로 들어있습니다(브랜드 순서는 실제로 이렇게 나열됐고, 인용 출처는 그때 수집하지 않아 비어 있습니다). 자동 파이프라인이 매일 실행되면서 이 위에 하루씩 데이터가 쌓여 날짜별 변화가 보이기 시작합니다.
